# test.py
import os
os.environ["TQDM_DISABLE_RICH"] = "1"
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'

import cv2
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
from stable_baselines3.common.monitor import Monitor

from fish_env import FishEnv  # 使用你提供的逃逸任务环境（保持不改动）

MODEL_PATH = "./models/fish_model_800000_steps.zip"     # 训练保存的模型
VECNORM_PATH = "./models/vecnormalize.pkl" # 若未来训练时保存了 VecNormalize 统计，这里会自动加载
VIDEO_PATH = "./logs/test_escape.mp4"
EPISODES = 5

def make_env_for_eval(render_mode="rgb_array"):
    # 与训练时的核心参数保持一致（可按需微调 predator_speed / max_steps 等）
    env = FishEnv(render_mode=render_mode, max_steps=2000, predator_speed=0.3)
    env = Monitor(env, "./logs")  # 方便记录回合信息
    return env

def main():
    os.makedirs("./logs", exist_ok=True)

    # 1) 加载模型
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"找不到模型文件: {MODEL_PATH}")

    print(f"Loading model from: {MODEL_PATH}")
    model = PPO.load(MODEL_PATH, device="cpu")  # 按需改为 "cuda"

    # 2) 构建评测环境（尝试加载 VecNormalize 统计；若不存在则回退为普通环境）
    env_raw = make_env_for_eval(render_mode="rgb_array")

    if os.path.exists(VECNORM_PATH):
        print(f"Loading VecNormalize stats from: {VECNORM_PATH}")
        # 先构造一个 dummy vecEnv，再把统计加载进去
        venv = DummyVecEnv([lambda: make_env_for_eval(render_mode="rgb_array")])
        env = VecNormalize.load(VECNORM_PATH, venv)
        env.training = False           # 评测模式
        env.norm_reward = False        # 测试时不做奖励归一化
    else:
        print("未发现 VecNormalize 统计文件，将在未归一化观测下评测（依然可运行）。")
        env = env_raw  # 直接使用未归一化环境
        # 若模型是在 VecNormalize 环境训练的，这里评测分布会略有漂移，但不影响脚本运行

    # 3) 预创建视频写入器（拿到第一帧的尺寸）
    if isinstance(env, VecNormalize):
        # VecNormalize 外面包着 DummyVecEnv
        # 需要 reset 一下拿到第一帧
        obs = env.reset()
        # 为避免 fish_env.render 访问 self.A/self.w 出错，先走一步：
        action = np.zeros((1, env.action_space.shape[0]), dtype=np.float32)
        _obs, _reward, _done, _info = env.step(action)
        # 从最内层拿帧
        frame = env.venv.envs[0].render()
        height, width = frame.shape[:2]
    else:
        obs, _ = env.reset()
        # 同理，先走一步，保证环境里 A/w 已初始化
        if hasattr(env, "action_space"):
            zero_act = env.action_space.sample() * 0.0
            _obs, _reward, _done, _trunc, _info = env.step(zero_act)
        frame = env.render()
        height, width = frame.shape[:2]

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    vw = cv2.VideoWriter(VIDEO_PATH, fourcc, 30, (width, height))
    print(f"Video writer opened: {VIDEO_PATH} (size: {width}x{height})")

    # 4) 回合循环并录制
    for ep in range(1, EPISODES + 1):
        if isinstance(env, VecNormalize):
            obs = env.reset()
        else:
            obs, _ = env.reset()

        done = False
        ep_reward = 0.0
        step = 0

        while not done:
            # 预测动作
            if isinstance(env, VecNormalize):
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, done, info = env.step(action)
                # 渲染帧（到最内层 env）
                frame = env.venv.envs[0].render()
            else:
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, done, trunc, info = env.step(action)
                # 直接渲染
                frame = env.render()

            ep_reward += float(reward)
            step += 1

            # 写帧
            if frame is not None:
                vw.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))

            # 如果 info 内含 success（你的 fish_env 在终止时会写入 episode_outcomes.csv）
            # 这里只打印提示即可
            if isinstance(info, dict) and "success" in info:
                pass

        print(f"[Episode {ep}] steps={step}, reward={ep_reward:.2f}")

    vw.release()
    if hasattr(env, "close"):
        env.close()
    print(f"测试完成，视频已保存到: {VIDEO_PATH}")

if __name__ == "__main__":
    main()
