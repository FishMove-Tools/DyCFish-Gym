import gymnasium as gym
from gymnasium import spaces
import numpy as np
import os
import ansys.fluent.core as pyfluent
import csv
import time
import random

class FluentEnv(gym.Env):
    def __init__(
        self,
        max_steps=2000,
        reward_function='escape',        # 控制任务修改为 escape
        simu_name="CFD_0",
        predator_speed=0.3,              # 捕食者速度
        capture_radius=0.1,              # 捕食者抓捕半径
    ):
        super().__init__()
        print(f"--- Initializing FluentEnv: {simu_name} ---")

        # === 参数初始化 ===
        self.simu_name = simu_name
        self.max_steps = max_steps
        self.reward_function = reward_function
        self.log_file = f"log_{simu_name}.csv"
        self.device = None
        self.action_summary_file = "action_summary.txt"
        
        # === 环境常量 ===
        self.predator_speed = predator_speed  # 捕食者速度
        self.capture_radius = capture_radius  # 捕食半径
        self.flow_domain_x_min = -4.0        # 流域 x 轴范围
        self.flow_domain_x_max = 12.0
        self.flow_domain_y_min = -2.0       # 流域 y 轴范围
        self.flow_domain_y_max = 2.0

        # === 物理/动作离散化参数（可按需调整） ===
        self.period_options = [2]  # 控制鱼体摆动周期的选项
        self.turning_options = [-0.1, 0.08, -0.06, -0.04, -0.02, 0, 0.02, 0.04, 0.06, 0.08, 0.1]  # 摆动幅度
        self.delta_options = [-1, 0, 1]  # [at_delta, tc_delta]

        # === 捕食者 ===
        self.predator_pos = np.zeros(2, dtype=np.float32)
        self._generate_predator_position()

        # === Gym 空间定义 ===
        # 状态空间：6维 [x, y, theta, vx, vy, wz, time]
        self.observation_space = spaces.Box(
            low=np.array([self.flow_domain_x_min, self.flow_domain_y_min, -np.pi, -np.inf, -np.inf, -np.inf, 0.0]),
            high=np.array([self.flow_domain_x_max, self.flow_domain_y_max,  np.pi, np.inf, np.inf, np.inf, np.inf]),
            dtype=np.float64
        )
        # 动作空间：2维 [frequency, amplitude] -> 映射到 [周期, 曲率系数]
        self.action_space = spaces.Box(
            low=np.array([0.0, 0.0]),  # [频率, 摆动幅度]
            high=np.array([2.0, np.pi/4]),
            dtype=np.float32
        )

        # === 状态变量 ===
        self.episode_number  = 0
        self.current_step    = 0
        self.simulation_time = 0.0
        self.time_step       = 0.01  # Fluent 仿真时间步长
        self.fish_position   = np.array([0.0, 0.0])
        self.fish_orientation = 0.0
        self.state = np.zeros(6, dtype=np.float64)

        # === 工作目录设置（按需修改/屏蔽） ===
        self.env_dir = os.path.join("fishmove", f"{self.simu_name}")
        os.makedirs(self.env_dir, exist_ok=True)
        os.chdir(self.env_dir)

        # === 控制台日志（transcript）路径 ===
        self.console_log = "fluent_console.log"
        self._transcript_active = False
        # === 启动 Fluent ===
        self.solver = pyfluent.launch_fluent(
            precision="double",
            processor_count=6,
            dimension=2,
            ui_mode="gui",  # gui | no_gui_or_graphics | no_gui
        )
        self.start_class(complete_reset=True)
        print(f"--- FluentEnv {self.simu_name} initialized ---")
        
    def _generate_predator_position(self):
        """生成捕食者初始位置，位于鱼体位置 0.5 ~ 1.0 米范围内"""
        r = random.uniform(0.5, 1.0)
        ang = random.uniform(1.5 * np.pi, 2 * np.pi)
        self.predator_pos = self.fish_position + r * np.array([np.cos(ang), np.sin(ang)], dtype=np.float32)

    def reset(self, seed=None, options=None):
        if seed is not None:
            np.random.seed(seed)
        self.initialize_flow(complete_reset=True)
        self.current_step    = 0
        self.episode_number += 1
        self.simulation_time = 0.0
        self.fish_position    = np.array([0.0, 0.0])
        self.fish_orientation = 0.0
        self.state = np.zeros(6, dtype=np.float64)
        self._generate_predator_position()  # 重置捕食者位置
        self.prev_target_distance = np.linalg.norm(self.fish_position - self.target_position)
        return self.state, {}

    def step(self, action):
        # 1) 解码控制动作 [频率, 摆动幅度]
        frequency = float(action[0])
        amplitude = float(action[1])
        # 2) 映射到周期和曲率系数
        period = 1.0 / frequency  # 摆动频率映射到周期
        A_s = (amplitude / (np.pi / 4)) * 1.4  # 映射到 A_s 范围
        # 摆动幅度与曲率系数的映射
        curvature = A_s * 0.1  # 曲率幅度映射到 [-0.1, 0.1] 范围
        # 3) 更新控制动作
        self.current_period_value = period
        self.current_turning_value = curvature
        steps_to_execute = int(self.current_period_value / self.time_step)

        # 4) 标志位
        failed = False
        success = False
        failure_reason = ""
        terminated = False
        truncated  = False
        step_i = -1

        # 5) Fluent 参数同步
        self.solver.execute_tui(f"/solve/set/time-step {self.time_step}")
        self.solver.execute_tui(f"(rpsetvar 'tc {self.current_period_value})")
        self.solver.execute_tui(f"(rpsetvar 'at {self.current_turning_value})")

        # 6) 在 Fluent 中推进
        for step_i in range(steps_to_execute):
            if step_i == 0:
                self.solver.execute_tui('/define/user-defined/execute-on-demand "add_action_from_console::libudf"')

            if self.current_step >= self.max_steps:
                truncated = True
                break
            try:
                self.simulation_time += self.time_step
                self.current_step += 1
                self.solver.execute_tui("/solve/dual-time-iterate 1 10")

                # 更新位姿
                xdisp, ydisp, thetadisp, _, _, _ = self._read_output_file()
                self.fish_position[0] = xdisp
                self.fish_position[1] = ydisp
                self.fish_orientation = thetadisp

                # 捕食者行为
                vec_pf = self.fish_position - self.predator_pos
                dist_pf = float(np.linalg.norm(vec_pf))
                if dist_pf > 1e-8:
                    self.predator_pos += (vec_pf / dist_pf) * self.predator_speed * self.time_step
                else:
                    jitter = (np.random.rand(2)-0.5)*1e-3
                    self.predator_pos += jitter.astype(np.float32)

                # 碰撞/越界
                obstacle_distance = self._calculate_obstacle_distance()
                if obstacle_distance < (self.obstacle_diameter / 2 + 0.02):
                    failed = True
                    failure_reason = "collision_with_obstacle"
                    terminated = True
                    break
                if (self.fish_position[0] > self.flow_domain_x_max or
                    self.fish_position[0] < self.flow_domain_x_min or
                    self.fish_position[1] > self.flow_domain_y_max or
                    self.fish_position[1] < self.flow_domain_y_min):
                    failed = True
                    failure_reason = "out_of_flow_domain"
                    terminated = True
                    break

            except Exception as e:
                print(f"[{self.simu_name}] Error in simulation step {step_i}: {e}")
                failed = True
                failure_reason = "fluent_exception"
                terminated = True
                break

        # 更新索引记录
        self.state = self._get_obs()
        target_distance   = np.linalg.norm(self.fish_position - self.target_position)
        success = (target_distance < 0.2)
        if success:
            terminated = True

        # 奖励计算（根据任务类型）
        reward = -target_distance * 10.0  # 基于目标距离
        success_reward = 1000 if success else 0

        if failed:
            if failure_reason == "collision_with_obstacle":
                reward -= 500
            elif failure_reason == "out_of_flow_domain":
                reward -= 400
            elif failure_reason == "fluent_exception":
                reward -= 1000

        info = {
            "simulation_time": self.simulation_time,
            "turning_action": self.current_turning_value,
            "period_action": self.current_period_value,
            "fish_position": self.fish_position.copy(),
            "fish_orientation": self.fish_orientation,
            "obstacle_distance": obstacle_distance,
            "target_distance": target_distance,
            "success": success,
            "failed": failed,
            "failure_reason": failure_reason,
            "timeout": truncated,
            "steps_executed": (step_i + 1) if step_i >= 0 else 0,
        }

        return self.state.copy(), reward + success_reward, terminated, truncated, info

    def close(self):
        if hasattr(self, 'solver') and self.solver is not None:
            try:
                self._stop_transcript_safe()
                self.solver.exit()
            except Exception as e:
                print(f"[{self.simu_name}] Error closing Fluent: {e}")

    def _log_variables(self):
        filename = "variable_record.txt"
        mode = "a" if os.path.exists(filename) else "w"
        with open(filename, mode, encoding="utf-8") as f:
            writer = csv.writer(f, delimiter=',', lineterminator="\n")
            if mode == "w":
                header = ["simulation_time", "x_disp", "y_disp", "theta_disp",
                          "turning_action", "period_action", "obstacle_distance", "target_distance"]
                writer.writerow(header)
            writer.writerow([self.simulation_time,
                self.fish_position[0],
                self.fish_position[1],
                self.fish_orientation,
                self.current_turning_value,
                self.current_period_value,
                self._calculate_obstacle_distance(),
                np.linalg.norm(self.fish_position - self.target_position)
            ])
