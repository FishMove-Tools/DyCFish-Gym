import os
# 关掉 tqdm 的 rich 后端，避免 Python 退出时报错
os.environ["TQDM_DISABLE_RICH"] = "1"
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'

import cv2
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
from stable_baselines3.common.vec_env import VecNormalize

from fish_env import FishEnv

# 目录
os.makedirs("./logs", exist_ok=True)
os.makedirs("./models", exist_ok=True)
os.makedirs("./tensorboard", exist_ok=True)

reward_log_file = "./logs/episode_rewards.txt"
if not os.path.exists(reward_log_file):
    with open(reward_log_file, "w") as f:
        pass

# 环境工厂：开启 human 渲染，但依靠 render_skip 节流

def make_env():
    env = FishEnv(render_mode='human', max_steps=2000, predator_speed=0.3,
                  render_skip=10, enable_step_logging=False)
    env = Monitor(env, './logs')
    return env

env = DummyVecEnv([make_env])
env = VecNormalize(env, norm_obs=True, norm_reward=True)

# 实时渲染回调（触发 env.render，但不每步都触发，由 env.render_skip 决定频率）
class RealTimeRenderCallback(BaseCallback):
    def __init__(self, every_calls: int = 1, verbose: int = 0):
        super().__init__(verbose)
        self.every_calls = max(1, int(every_calls))
        self._calls = 0

    def _on_step(self) -> bool:
        self._calls += 1
        if (self._calls % self.every_calls) == 0:
            try:
                # 取最底层的 env（去掉 VecNormalize/Monitor 包裹）
                env0 = self.training_env
                if hasattr(env0, 'envs'):
                    env0 = env0.envs[0]
                if hasattr(env0, 'env'):
                    env0 = env0.env
                # 触发渲染（env 内部用 render_skip 控制频率）
                if getattr(env0, 'render_mode', None) == 'human':
                    env0.render()
            except Exception:
                pass
        return True

# 每个 episode 的奖励与步数——按回合统计（不是累计步数）
class RewardLoggingCallback(BaseCallback):
    def __init__(self, log_file, verbose=0):
        super().__init__(verbose)
        self.log_file = log_file
        self.episode_rewards = []
        self.current_episode_reward = 0.0
        self.episode_count = 0
        self.total_steps = 0  # 全局总步数
        self.episode_step_count = 0  # 当前回合已走步数
        # 初始化日志
        with open(self.log_file, "w") as f:
            f.write("Training Progress:\n")
            f.write("Episode,Episode Steps,Episode Reward,Total Steps\n")

    def _on_step(self) -> bool:
        r = float(self.locals['rewards'][0])
        d = bool(self.locals['dones'][0])
        self.current_episode_reward += r
        self.total_steps += 1
        self.episode_step_count += 1

        if d:
            self.episode_count += 1
            # 写入：本回合步数=episode_step_count（不一定是 2000）
            with open(self.log_file, "a") as f:
                f.write(f"{self.episode_count},{self.episode_step_count},{self.current_episode_reward:.2f},{self.total_steps}\n")
            print(f"Episode {self.episode_count} | steps: {self.episode_step_count} | reward: {self.current_episode_reward:.2f}")
            self.episode_rewards.append(self.current_episode_reward)
            # 重置回合累积
            self.current_episode_reward = 0.0
            self.episode_step_count = 0
        return True

    def _on_training_end(self) -> None:
        if len(self.episode_rewards) == 0:
            return
        with open(self.log_file, "a") as f:
            f.write("\nTraining Summary:\n")
            f.write(f"Total Steps: {self.total_steps}\n")
            f.write(f"Total Episodes: {self.episode_count}\n")
            f.write(f"Average Reward: {np.mean(self.episode_rewards):.2f}\n")
            f.write(f"Max Reward: {np.max(self.episode_rewards):.2f}\n")
            f.write(f"Min Reward: {np.min(self.episode_rewards):.2f}\n")

# 检点回调
checkpoint_callback = CheckpointCallback(save_freq=10_000, save_path='./models/', name_prefix='fish_model')
render_callback = RealTimeRenderCallback(every_calls=1)
reward_logging_callback = RewardLoggingCallback(log_file=reward_log_file)

# 模型
model = PPO(
    "MlpPolicy",
    env,
    verbose=1,
    learning_rate=3e-4,
    n_steps=2048,
    batch_size=64,
    n_epochs=10,
    gamma=0.99,
    ent_coef=0.005,
    clip_range=0.2,
    tensorboard_log="./tensorboard/"
)

try:
    model.learn(
        total_timesteps=1_000_000,
        callback=[checkpoint_callback, render_callback, reward_logging_callback],
        progress_bar=False  # 关闭 tqdm rich，避免退出时报错
    )
    model.save("./models/fish_final")
    print(f"Training done. Episode rewards logged at {reward_log_file}")
except KeyboardInterrupt:
    print("\nTraining interrupted. Saving model...")
    model.save("./models/fish_interrupted")
finally:
    env.close()
