# =========================
# fish_env.py (REVISED)
# =========================
import math
import numpy as np
import gymnasium as gym
from gymnasium import spaces
import torch
import pygame
import os
import csv
import random

# 如果是多核 CPU，可以设置线程数
torch.set_num_threads(4)

# 检查 GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")


class FishEnv(gym.Env):
    """
    鱼游逃逸任务环境：
    - 每个 episode，捕食者在 1.0 m 半径内随机生成并追击；
    - 被捕（距离 <= capture_radius）则失败，终止 episode；
    - 存活到 max_steps 视为成功；
    - 支持人类可视化；支持缓冲写盘避免卡顿；
    - episode 结果写入 episode_outcomes.csv。
    """

    metadata = {
        'render_modes': ['human', 'rgb_array'],
        'render_fps': 30
    }

    def __init__(self, dt=0.01, max_steps=2000, render_mode='human',
                 predator_speed=0.3, capture_radius=0.1,
                 render_skip=10, enable_step_logging=False):
        super(FishEnv, self).__init__()
        # ------- 基本参数 -------
        self.dt = dt
        self.max_steps = max_steps
        self.render_mode = render_mode
        self.render_skip = int(render_skip)  # 仅在 human 模式下每 render_skip 步渲染一次
        self.enable_step_logging = bool(enable_step_logging)  # 是否逐步记录到缓冲

        # ------- 鱼身参数 -------
        self.mb = 1.0   # 鱼体质量
        self.Jb = 0.005 # 鱼体惯性矩
        self.mt = 0.2   # 尾部质量
        self.Jt = 0.001 # 尾部惯性矩
        self.r_ = 0.3   # 尾部到鱼体质心的距离

        # ------- 观测与动作空间 -------
        obs_high = np.array([100.0]*7, dtype=np.float32)  # [pos_x, pos_y, yaw, vbx, vby, wbz, t]
        self.observation_space = spaces.Box(-obs_high, obs_high, dtype=np.float32)
        self.action_space = spaces.Box(
            low=np.array([0, math.pi]),
            high=np.array([math.pi / 4, math.pi * 2]),
            dtype=np.float32
        )

        # ------- 状态变量 -------
        self.pos = np.zeros(2, dtype=np.float32)
        self.yaw = 0.0
        self.Vb = np.zeros(3, dtype=np.float32)
        self.Wb = np.zeros(3, dtype=np.float32)
        self.time = 0.0
        self.current_step = 0

        # ------- 捕食者 -------
        self.predator_speed = float(predator_speed)
        self.capture_radius = float(capture_radius)
        self.predator_pos = np.zeros(2, dtype=np.float32)

        # ------- 记录控制 -------
        self.episode_index = 0
        self.episode_logged = False
        self._log_buffer = []  # 逐步记录缓冲（避免每步写盘）

        # ------- 渲染 -------
        self.screen_dim = 600
        self.scale = 100.0
        self.screen = None
        self.clock = None

    # ------------------------ reset ------------------------
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.pos[:] = 0.0
        self.yaw = 0.0
        self.Vb[:] = 0.0
        self.Wb[:] = 0.0
        self.time = 0.0
        self.current_step = 0
        self.episode_logged = False
        self._log_buffer = []

        # 捕食者初始位置（0.2~1.0 m 环带）
        r = random.uniform(0.5, 1.0)
        ang = random.uniform(1.5*math.pi, 2*math.pi)
        self.predator_pos = self.pos + r * np.array([math.cos(ang), math.sin(ang)], dtype=np.float32)

        return self._get_obs(), {}

    # ------------------------ step ------------------------
    def step(self, action):
        self.A = float(action[0])
        self.w = float(action[1])

        # 物理推进
        self._update_dynamics()

        # 捕食者向鱼移动
        vec_pf = self.pos - self.predator_pos
        dist_pf = float(np.linalg.norm(vec_pf))
        if dist_pf > 1e-8:
            self.predator_pos += (vec_pf / dist_pf) * self.predator_speed * self.dt
        else:
            # 重合时随机抖动一下捕食者，避免卡住
            jitter = (np.random.rand(2)-0.5)*1e-3
            self.predator_pos += jitter.astype(np.float32)
            dist_pf = 0.0

        # 奖励（速度/距离 shaping）
        cos_yaw = math.cos(self.yaw); sin_yaw = math.sin(self.yaw)
        vx_world = cos_yaw * self.Vb[0] - sin_yaw * self.Vb[1]
        vy_world = sin_yaw * self.Vb[0] + cos_yaw * self.Vb[1]
        unit_away = (vec_pf / (dist_pf + 1e-8)) if dist_pf > 0 else np.zeros(2, dtype=np.float32)
        v_away = vx_world*unit_away[0] + vy_world*unit_away[1]

        r_live, k_dist, k_vx, k_away = 0.02, 0.2, 0.3, 0.5
        k_vy, k_wz, k_Areg, k_wreg   = 0.15, 0.05, 0.002, 0.0005

        reward  = 0.0
        reward += r_live
        reward += k_dist * min(dist_pf, 1.5)
        reward += k_vx   * max(0.0, vx_world)
        reward += k_away * max(0.0, v_away)
        reward -= k_vy   * abs(vy_world)
        reward -= k_wz   * abs(self.Wb[2])
        reward -= k_Areg * (self.A ** 2)
        reward -= k_wreg * (self.w ** 2)

        terminated = False
        truncated = False
        reason = None

        # 捕获终止
        if dist_pf <= self.capture_radius:
            terminated = True
            reward -= 50.0
            reason = "captured"

        # 出界处理（可选）
        if not terminated and (abs(self.pos[0]) > 50 or abs(self.pos[1]) > 50):
            terminated = True
            reward -= 10.0
            reason = "out_of_bounds"

        self.current_step += 1

        # 存活到最大步数：成功
        if not terminated and self.current_step >= self.max_steps:
            terminated = True  # 用 terminated=True 结束（方便算法统计）
            reward += 100.0
            reason = "timeout_survive"

        # 仅在需要实时渲染时节流绘制
        if self.render_mode == "human" and (self.current_step % max(1, self.render_skip) == 0):
            self.render()

        # 记录 episode 成败（只记一次）
        if terminated and (not self.episode_logged):
            success = (reason == "timeout_survive")
            self._log_episode_outcome(success=success, steps=self.current_step, reason=reason or "none")
            # 将逐步缓冲写盘（避免每步 I/O）
            self._flush_step_buffer()
            self.episode_logged = True
            self.episode_index += 1

        return self._get_obs(), reward, terminated, False, {}

    # ------------------------ 观测 ------------------------
    def _get_obs(self):
        return np.array([
            self.pos[0], self.pos[1], self.yaw,
            self.Vb[0], self.Vb[1], self.Wb[2], self.time
        ], dtype=np.float32)

    # ------------------------ 动力学 ------------------------
    def _update_dynamics(self):
        dt = self.dt
        t = self.time

        theta = self.A * math.cos(self.w * t)
        dtheta = - self.w * self.A * math.sin(self.w * t)
        ddtheta = - (self.w**2) * self.A * math.cos(self.w * t)

        r_bt = self.r_ * np.array([math.cos(theta), math.sin(theta), 0.0])
        Wt = self.Wb + dtheta * np.array([0, 0, 1])
        Vt = self.Vb + np.cross(Wt, r_bt)

        CFb = 10 * np.array([0.1, 0.01, 0])
        Fdb = -0.5 * CFb * np.sign(self.Vb) * (self.Vb**2)
        CMb = np.array([0, 0, 1])
        Mdb = -0.5 * CMb * np.sign(self.Wb) * (self.Wb**2)
        CFt = np.array([0.1, 0.1, 0.1])
        Fdt = -0.5 * CFt * np.sign(Vt) * (Vt**2)

        F1 = self.mt * (
            np.cross(r_bt, ddtheta * np.array([0, 0, 1]))
            - np.cross(Wt, self.Vb)
            - np.cross(Wt, np.cross(Wt, r_bt))
        )
        M1 = (
            - self.Jt * ddtheta * np.array([0, 0, 1])
            - np.cross(Wt, self.Jt * Wt)
            + np.cross(r_bt, F1)
        )

        K = np.concatenate([
            self.mb * np.cross(self.Wb, self.Vb) - F1 - Fdb,
            np.cross(self.Wb, self.Jb * self.Wb) - M1 - Mdb
        ])

        r_bt_cross = np.array([[0, -r_bt[2], r_bt[1]],
                               [r_bt[2], 0, -r_bt[0]],
                               [-r_bt[1], r_bt[0], 0]])
        H = np.block([[-(self.mt + self.mb) * np.eye(3), self.mt * r_bt_cross],
                      [-self.mt * r_bt_cross, -(self.Jt + self.Jb) * np.eye(3) + self.mt * (r_bt_cross @ r_bt_cross)]])
        # 数值稳健：正则 + solve
        H_reg = H + 1e-8 * np.eye(6)
        U = np.linalg.solve(H_reg, K)
        dVb, dWb = U[:3], U[3:]

        self.Vb += dVb * dt
        self.Wb += dWb * dt
        self.yaw += self.Wb[2] * dt

        cos_yaw = math.cos(self.yaw)
        sin_yaw = math.sin(self.yaw)
        vx_world = cos_yaw * self.Vb[0] - sin_yaw * self.Vb[1]
        vy_world = sin_yaw * self.Vb[0] + cos_yaw * self.Vb[1]
        self.pos[0] += vx_world * dt
        self.pos[1] += vy_world * dt

        # 逐步变量缓冲（避免每步落盘卡顿）
        if self.enable_step_logging:
            self._log_buffer.append([self.pos[0], self.pos[1], self.yaw,
                                     self.Vb[0], self.Vb[1], self.Wb[2]])

        self.time += dt

    # ------------------------ 写盘工具 ------------------------
    def _flush_step_buffer(self):
        if not self._log_buffer:
            return
        header_needed = not os.path.exists("varable_record.txt")
        with open("varable_record.txt", "a", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            if header_needed:
                w.writerow(["posx","posy","yaw","Vbx","Vby","Wbz"])
            w.writerows(self._log_buffer)
        self._log_buffer = []

    def _log_episode_outcome(self, success: bool, steps: int, reason: str):
        header_needed = not os.path.exists("episode_outcomes.csv")
        with open("episode_outcomes.csv", "a", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            if header_needed:
                w.writerow(["episode", "success", "steps", "reason"])  # 写表头
            w.writerow([self.episode_index, bool(success), int(steps), str(reason)])

    # ------------------------ 渲染 ------------------------
    def render(self):
        if self.render_mode is None:
            return None
        if self.screen is None:
            pygame.init()
            pygame.display.init()
            self.screen = pygame.display.set_mode((self.screen_dim, self.screen_dim))
            self.clock = pygame.time.Clock()
        if self.clock is None:
            self.clock = pygame.time.Clock()

        self.screen.fill((255, 255, 255))

        # 参考线
        center = (self.screen_dim // 2, self.screen_dim // 2)
        cx, cy = center
        pygame.draw.line(self.screen, (200, 200, 200), (cx, 0), (cx, self.screen_dim), 1)
        pygame.draw.line(self.screen, (200, 200, 200), (0, cy), (self.screen_dim, cy), 1)

        # 鱼体
        body_poly = np.array([[-0.25, -0.1], [0.25, -0.1], [0.25, 0.1], [-0.25, 0.1]], dtype=np.float32)
        tail_poly = np.array([[0.0, -0.05], [0.3, -0.05], [0.3, 0.05], [0.0, 0.05]], dtype=np.float32)
        theta = self.A * math.cos(self.w * self.time)

        cos_yaw = math.cos(self.yaw); sin_yaw = math.sin(self.yaw)
        R_body = np.array([[cos_yaw, -sin_yaw], [sin_yaw, cos_yaw]], dtype=np.float32)
        body_world = (R_body @ body_poly.T).T * self.scale
        body_world[:, 0] += (self.pos[0] * self.scale + cx)
        body_world[:, 1] += (self.pos[1] * self.scale + cy)

        cos_t = math.cos(theta); sin_t = math.sin(theta)
        R_tail_local = np.array([[cos_t, -sin_t], [sin_t, cos_t]], dtype=np.float32)
        tail_world = (R_tail_local @ tail_poly.T).T
        tail_base_body = np.array([0.25, 0.0], dtype=np.float32)
        tail_base_world = (R_body @ tail_base_body) * self.scale
        tail_world *= self.scale
        tail_world[:, 0] += (tail_base_world[0] + self.pos[0]*self.scale + cx)
        tail_world[:, 1] += (tail_base_world[1] + self.pos[1]*self.scale + cy)

        pygame.draw.polygon(self.screen, (0, 0, 255), np.round(body_world).astype(np.int32))
        pygame.draw.polygon(self.screen, (255, 0, 0), np.round(tail_world).astype(np.int32))

        # 捕食者
        pred_px = int(self.predator_pos[0] * self.scale + cx)
        pred_py = int(self.predator_pos[1] * self.scale + cy)
        pygame.draw.circle(self.screen, (255, 0, 0), (pred_px, pred_py), 5)
        try:
            font = pygame.font.SysFont(None, 18)
            label = font.render('predator', True, (0, 0, 0))
            self.screen.blit(label, (pred_px + 6, pred_py - 6))
        except Exception:
            pass

        if self.render_mode == "human":
            pygame.event.pump()  # 避免窗口阻塞
            pygame.display.flip()
            self.clock.tick(self.metadata["render_fps"])  # 仅限制渲染速率
            return None
        elif self.render_mode == "rgb_array":
            # 生成帧（RGB）以便录制
            arr = pygame.surfarray.array3d(self.screen)
            return np.transpose(arr, axes=(1, 0, 2))

    def close(self):
        if self.screen is not None:
            pygame.display.quit()
            pygame.quit()


